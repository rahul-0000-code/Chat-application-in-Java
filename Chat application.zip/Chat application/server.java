import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.*;

import javax.swing.text.AbstractDocument.Content;

import java.io.*;

class server {
    ServerSocket server;
    Socket socket;

    BufferedReader br;
    PrintWriter out;

    public server() // Constructor..
    {
        try {
            server = new ServerSocket(7777);
            System.out.println("Server is ready to accept connection");
            System.out.println("Waiting....");
            socket = server.accept();

            br = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            out = new PrintWriter(socket.getOutputStream());

            startReading();
            startWriting();

        } catch (Exception e) {
            e.printStackTrace();

        }

    }

    public void startReading() {
        // this thread will read the data for us
        Runnable r1 = () -> {

            System.out.println("reader started..");

            while (true) {
                try {
                    String msg = br.readLine();
                    if (msg.equals("exit")) {
                        System.out.println("Client terminated the chat");
                        break;
                    }

                    System.out.println("Client :" + msg);
                } catch (Exception e) {
                    System.out.println(e);
                }
            }

        };

        new Thread(r1).start();
    }

    public void startWriting() {
        // this data will be sent to client by the server
        Runnable r2 = () -> {
            while (true) {
                try {
                    BufferedReader br1 = new BufferedReader(new InputStreamReader(System.in));
                    String content = br1.readLine();
                    out.println(content);
                    out.flush();

                } catch (Exception e) {
                    // to handle exception
                    e.printStackTrace();
                }
            }

        };

        new Thread(r2).start();
    }

    public static void main(String[] args) {

        System.out.println("this is server..going to start server");
        new server();
    }
}